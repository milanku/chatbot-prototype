# Disputes and Chargebacks Policy

## 1. When to Use This Process

This policy applies when a customer disputes a transaction due to:

- unauthorized card transaction
- duplicate charge
- incorrect amount
- goods/services not received
- refunds not processed
- subscription cancellation disputes

## 2. First Steps Before Filing a Dispute

Customers should:

- check transaction details (merchant name can differ from storefront brand)
- contact the merchant for clarification or refund
- collect evidence (receipts, cancellation confirmation, correspondence)

## 3. Dispute Types

### 3.1 Card Transaction Chargeback

A card scheme process used to contest eligible card transactions.

### 3.2 Transfer Recall / Investigation

Applies to bank transfers. Recovery may not be possible if funds have been withdrawn by the recipient.

## 4. Time Limits (General Guidance)

Time limits vary by scheme and reason code. As a general guideline:

- customers should report unauthorized transactions as soon as possible after discovery
- disputes for goods/services issues should be filed promptly after expected delivery or refund date

## 5. Evidence Requirements

Depending on dispute reason, evidence may include:

- proof of purchase or refund promise
- delivery tracking or lack of delivery
- subscription cancellation confirmation
- police report (in some fraud cases)

## 6. Provisional Credit

In some cases, the bank may issue provisional credit during investigation.
Provisional credit may be reversed if the dispute is not upheld.

## 7. Fraud and Security Holds

If fraud is suspected:

- the bank may place holds or block cards (see Accounts and Access Policy; Cards and Payments Policy)
- the bank may require re-verification before processing additional transactions

## 8. Outcomes

Disputes may result in:

- chargeback success and funds returned
- dispute rejected due to insufficient evidence or ineligible reason
- partial adjustment in some cases
