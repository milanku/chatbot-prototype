# Fees and Pricing Policy

## 1. General
Fees depend on product type, usage, and customer plan. Some fees may be waived for eligible customers.

## 2. Account Fees
- Monthly account maintenance fee may apply depending on plan.
- Inactivity or dormancy-related reactivation checks may apply in certain cases.

## 3. Card Fees
### 3.1 Card Replacement
- Replacement for damaged cards may be free or charged depending on plan.
- Replacement for lost/stolen cards may incur a fee.

### 3.2 Card Delivery
- Standard delivery may be included; express delivery may be charged.

## 4. Transfer Fees
- Domestic transfers may be free or charged depending on plan.
- International transfers may include bank fees and correspondent bank fees.

## 5. Cash Withdrawal Fees
- Some ATM withdrawals may be charged (especially out-of-network or international).
- FX conversion may apply for international ATM withdrawals.

## 6. Foreign Exchange (FX)
FX costs can include:
- card scheme exchange rate
- bank FX margin
- additional “international usage” fee (if applicable)

## 7. Dispute/Chargeback Fees
- The bank generally does not charge a fee for filing a chargeback.
- Some dispute outcomes (e.g., repeated invalid disputes) may be subject to administrative fees depending on plan and jurisdiction.

## 8. Notifications and Paper Statements
- Paper statements may incur a fee.
- Certain premium notification options may be charged.