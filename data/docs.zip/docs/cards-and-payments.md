# Cards and Payments Policy

## 1. Card Types and Supported Payments

- Debit card (personal and joint accounts)
- Virtual card (where available)
- Contactless and mobile wallet payments (where available)

## 2. Card Payment Types

### 2.1 Card-Present

Used in-store with chip + PIN or contactless.

### 2.2 Card-Not-Present (Online / Phone)

Online purchases, subscription payments, and merchant-initiated transactions may occur without PIN.
Additional authentication may be required (e.g., 3D Secure / strong customer authentication).

### 2.3 Recurring and Merchant-Initiated Transactions

- Some recurring charges may bypass interactive authentication.
- Customers should cancel subscriptions with the merchant; blocking a card does not always stop all merchant-initiated charges.

## 3. Limits

### 3.1 Default Limits

The bank sets default daily limits for:

- ATM cash withdrawals
- in-store card purchases
- online card purchases

### 3.2 Changing Limits

- Limit increases may require MFA and additional verification.
- New devices or suspicious activity may prevent limit increases temporarily.

### 3.3 Declines

A transaction may be declined due to:

- insufficient funds
- exceeded limit
- merchant risk or fraud rules
- security holds (see Accounts and Access Policy)

## 4. Card Blocking and Replacement

### 4.1 Customer-Initiated Block

Customers can block a card via app/web or by calling support.
Blocking is immediate for new authorizations.

### 4.2 Replacement

Replacement cards may be issued if:

- card is lost/stolen
- card is damaged
- card is compromised

## 5. Cash Withdrawals

ATM withdrawals may be subject to:

- daily withdrawal limits
- additional verification after suspicious activity
- temporary blocks if fraud is suspected

## 6. FX and International Usage

Card purchases in foreign currency may include:

- scheme exchange rate
- bank FX margin
- additional fees as described in Fees and Pricing Policy

## 7. Payment Reversals vs Chargebacks

- A **reversal** is initiated by the merchant and can happen shortly after authorization.
- A **chargeback** is a dispute process (see Disputes and Chargebacks Policy) and may take longer.
