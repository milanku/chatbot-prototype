# Accounts and Access Policy

## 1. Scope

This policy applies to personal current accounts, savings accounts, and joint accounts offered by the bank. It also applies to access via mobile banking, web banking, and customer support.

## 2. Opening an Account

- Personal current accounts can be opened digitally or in-branch.
- Joint accounts require identity verification for all account holders.
- The bank may refuse account opening if required documents cannot be verified or if risk checks fail.

## 3. Access Channels

### 3.1 Mobile and Web Banking

- Login requires an approved authentication factor (e.g., password + MFA).
- Devices may be registered for “trusted device” status.
- The bank may restrict certain actions on new devices or after suspicious activity.

### 3.2 Customer Support Access

Customer support can:

- help with login/access issues
- block cards and accounts
- provide transaction information (subject to identity checks)

Customer support cannot:

- disclose sensitive account details without identity verification
- override security holds without a documented resolution process

## 4. Authentication and Session Security

- Multi-factor authentication (MFA) is required for high-risk actions such as changing contact details, adding new beneficiaries, or increasing limits.
- Sessions may time out after inactivity.
- The bank may require re-authentication to confirm critical actions.

## 5. Security Holds and Temporary Restrictions

The bank may place a temporary hold on:

- outbound transfers
- card-not-present purchases
- changes to account details

Common triggers:

- unusual spending pattern
- rapid repeated failed login attempts
- beneficiary added + transfer attempted shortly after
- suspected fraud indicators from monitoring systems

Holds are lifted after:

- customer completes verification, or
- bank completes internal review, or
- transaction is cancelled/declined

## 6. Joint Accounts

- Each holder may have their own access credentials.
- Either holder may request card blocking and report suspicious transactions.
- Dispute processes may require confirmation depending on the transaction type and account permissions.

## 7. Dormant Accounts

Accounts with no customer-initiated activity for an extended period may be considered dormant.
Dormant accounts may have:

- restricted access until re-verification is completed
- additional checks before outbound transfers are allowed
