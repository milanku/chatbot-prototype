# Digital Banking and Support Processes

## 1. Supported Channels

- In-app chat (where available)
- phone support
- secure messaging via web/mobile banking

## 2. Common Support Requests

Support can assist with:

- card blocking and replacement requests
- disputes intake and status updates
- login troubleshooting and MFA resets (subject to verification)
- transaction clarifications (merchant descriptor lookup)

## 3. Complaint Handling

Customers can file complaints regarding:

- fees and pricing
- service availability
- dispute outcomes
- account restrictions and holds

Complaints may require:

- a written summary
- supporting documents
- up to several business days for investigation depending on complexity

## 4. Outages and Degraded Service

During outages:

- some actions may not be available in digital channels
- customers may be directed to phone support for urgent issues (e.g., card block)

## 5. Security Escalations

If suspicious activity is detected:

- support may trigger security holds (see Accounts and Access Policy)
- additional verification may be required before changes are made
- the bank may recommend card replacement (see Cards and Payments Policy; Disputes and Chargebacks Policy)
