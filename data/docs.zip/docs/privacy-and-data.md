# Privacy and Data Handling Policy

## 1. Data We Process

The bank may process:

- identity and contact details
- account details and balances
- transaction history and merchant details
- device and session metadata for security

## 2. Purposes

Data is processed for:

- providing banking services
- fraud prevention and security monitoring
- compliance with legal obligations
- customer support and service improvement

## 3. Sharing

The bank may share data with:

- payment networks and processors for transaction processing
- service providers under contractual safeguards
- regulators or law enforcement where legally required

## 4. Retention

Transaction data and account records may be retained for statutory periods and operational needs.

## 5. Customer Requests

Customers may request:

- access to personal data
- corrections to inaccurate data
- information on how data is processed (subject to legal limitations)

## 6. Security Measures

The bank uses layered security including:

- access controls and encryption
- monitoring for suspicious activity
- authentication requirements for sensitive actions
