# Loans and Credit Policy

## 1. Product Scope

This policy covers personal loans and overdraft facilities attached to current accounts.

## 2. Eligibility and Approval

Approval is subject to:

- identity verification
- affordability assessment
- risk checks and internal scoring

## 3. Repayments

### 3.1 Scheduled Repayments

Repayments are typically taken monthly from the linked current account.

### 3.2 Missed Repayments

If a repayment is missed:

- late fees or penalty interest may apply (see Fees and Pricing Policy)
- the bank may contact the customer to arrange payment
- account restrictions may apply in severe or repeated cases

## 4. Early Repayment

Customers may be able to repay early.
Early repayment may:

- reduce interest
- incur early repayment fees depending on product terms

## 5. Overdraft

Overdraft usage may:

- incur interest or fees
- be subject to limits that can change based on risk assessment

## 6. Disputes Related to Credit Products

Disputes about loan repayment amounts or fees may require:

- review of repayment schedule
- account statements and transaction history
